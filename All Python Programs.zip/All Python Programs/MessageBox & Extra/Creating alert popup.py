from tkinter import *
from tkinter import messagebox
a2=Tk()
def hello():
    b=a.get()
    lbl=Label(text=b,fg='pink',bg='black',font=('times',34,'italic')).pack()
def dele():
    lb9=Label(text='Deleted',fg='pink',bg='green',font=('arial',10,'bold')).pack() 
def mbox():
    messagebox.showinfo(title='Save',message='Are you sure to save')
def mquit():
    mess=messagebox.askyesno(title='quit',message='Are you sure to quit')
    if mess==1:
        a2.destroy()
        
a=StringVar()
a2.title("My first Window")
a2.geometry("500x500+100+50")
mylbl=Label(text='First name :',fg='red',bg='blue').pack()
mybtn1=Button(text='Enter',fg='red',bg='Green',command=hello).pack()
mybtn2=Button(text='Delete',fg='blue',bg='red',command=dele).pack()
text=Entry(textvariable=a).pack()
m=Menu()
l3=Menu()
m.add_cascade(label='File',menu=l3)
a2.config(menu=m)
l3.add_command(label='Save',command=mbox)
l3.add_command(label='Quit',command=mquit)
a2.mainloop()
