from tkinter import *
a2=Tk()
def hello():
    b=a.get()
    l=Label(text=b,fg='red',bg='blue',font=27).pack()
    
a=StringVar()
a2.title("python")
a2.geometry("400x400+100+50")
lbl=Label(text='label one',fg='black',bg='blue').pack()
btn=Button(text='Enter',fg='red',bg='yellow',command=hello,font=45).pack()
text=Entry(textvariable=a).pack()
a2.mainloop()
