Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: C:/Users/Sachin/AppData/Local/Programs/Python/Python38/mymath.py ==
>>> import mymath
>>> mymath.addition(80,20)
80 + 20 = 100
>>> mymath.division(80,20)
80 / 20 = 4.0
>>> mymath.multiplication(5,9)
5 * 9 = 45
>>> mymath.subtraction(100,67)
100 - 67 = 33
>>> 