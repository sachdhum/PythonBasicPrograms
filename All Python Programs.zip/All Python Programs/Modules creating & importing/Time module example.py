Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import time
>>> time.time()
1592995773.4201233
>>> time.localtime(1592995773.4201233)
time.struct_time(tm_year=2020, tm_mon=6, tm_mday=24, tm_hour=16, tm_min=19, tm_sec=33, tm_wday=2, tm_yday=176, tm_isdst=0)
>>> time.asctime()
'Wed Jun 24 16:20:02 2020'
>>> t=time.asctime()
>>> t
'Wed Jun 24 16:20:18 2020'
>>> lin=time.time()
>>> mes=time.time()
>>> lout=time.time()
>>> lin1=time.localtime(lin)
>>> mes1=time.localtime(mes)
>>> lout1=time.localtime(lout)
>>> login=time.asctime(lin1)
>>> msg=time.asctime(mes1)
>>> logout=time.asctime(lout1)
>>> login
'Wed Jun 24 16:20:55 2020'
>>> msg
'Wed Jun 24 16:21:07 2020'
>>> logout
'Wed Jun 24 16:21:25 2020'
>>> 