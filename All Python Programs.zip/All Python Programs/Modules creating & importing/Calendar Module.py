Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import calendar
>>> calendar.isleap(2012)
True
>>> calendar.isleap(2003)
False
>>> print(calendar.month(2020,6))
     June 2020
Mo Tu We Th Fr Sa Su
 1  2  3  4  5  6  7
 8  9 10 11 12 13 14
15 16 17 18 19 20 21
22 23 24 25 26 27 28
29 30

>>> print(calendar.calendar(2020,2,1,10))
                                      2020

      January                       February                       March
Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su
       1  2  3  4  5                          1  2                             1
 6  7  8  9 10 11 12           3  4  5  6  7  8  9           2  3  4  5  6  7  8
13 14 15 16 17 18 19          10 11 12 13 14 15 16           9 10 11 12 13 14 15
20 21 22 23 24 25 26          17 18 19 20 21 22 23          16 17 18 19 20 21 22
27 28 29 30 31                24 25 26 27 28 29             23 24 25 26 27 28 29
                                                            30 31

       April                          May                           June
Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su
       1  2  3  4  5                       1  2  3           1  2  3  4  5  6  7
 6  7  8  9 10 11 12           4  5  6  7  8  9 10           8  9 10 11 12 13 14
13 14 15 16 17 18 19          11 12 13 14 15 16 17          15 16 17 18 19 20 21
20 21 22 23 24 25 26          18 19 20 21 22 23 24          22 23 24 25 26 27 28
27 28 29 30                   25 26 27 28 29 30 31          29 30

        July                         August                      September
Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su
       1  2  3  4  5                          1  2              1  2  3  4  5  6
 6  7  8  9 10 11 12           3  4  5  6  7  8  9           7  8  9 10 11 12 13
13 14 15 16 17 18 19          10 11 12 13 14 15 16          14 15 16 17 18 19 20
20 21 22 23 24 25 26          17 18 19 20 21 22 23          21 22 23 24 25 26 27
27 28 29 30 31                24 25 26 27 28 29 30          28 29 30
                              31

      October                       November                      December
Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su          Mo Tu We Th Fr Sa Su
          1  2  3  4                             1              1  2  3  4  5  6
 5  6  7  8  9 10 11           2  3  4  5  6  7  8           7  8  9 10 11 12 13
12 13 14 15 16 17 18           9 10 11 12 13 14 15          14 15 16 17 18 19 20
19 20 21 22 23 24 25          16 17 18 19 20 21 22          21 22 23 24 25 26 27
26 27 28 29 30 31             23 24 25 26 27 28 29          28 29 30 31
                              30

>>> 