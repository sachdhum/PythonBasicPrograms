from tkinter import *
a=Tk()
a.title("Python")
a.mainloop()
