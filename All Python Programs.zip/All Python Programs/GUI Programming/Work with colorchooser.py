from tkinter import *
import tkinter.colorchooser
from tkinter import choosecolor 
  
a2=Tk()
 
color=colorchooser.askcolor()
label=Label(text=color).pack()
a2.mainloop()
 
