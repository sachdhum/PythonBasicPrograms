from tkinter import *
from tkinter import filedialog
from tkinter.filedialog import askopenfilename
from tkinter import colorchooser
colorchooser.askcolor()
a2=Tk()
def mcolor():
    col=colorchooser.askcolor()
    label=Label(text='Your choosen color',bg=color[1]).pack()
def mfileopen():
    f=filedialog.askopenfile()
    l=Label(text=f).pack()
btn=Button(text='choose color',width=30,command=mcolor).pack()
btn2=Button(text='open file',width=30,command=mfileopen).pack()
a2.mainloop()
    
