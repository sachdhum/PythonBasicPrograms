from tkinter import *
a=Tk()
a.title("Python")
l=Label(text='Enter the name',fg='red',bg='yellow').pack()
a.geometry("400x100+200+200")
a.mainloop()
