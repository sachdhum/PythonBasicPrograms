from tkinter import *
a=Tk()
a.title("Python")
a.geometry("400x100+200+200")
a.mainloop()
