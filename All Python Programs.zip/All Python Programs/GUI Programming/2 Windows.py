                           # 2 Windows

from tkinter import *
b=Tk()
c=Tk()
b.title("cricbuzz")
b.geometry('200x200+100+100')
c.title("ESPN Cricinfo")
c.geometry('200x200+100+100')
b1=Button(b,text='Enter').pack()
b2=Button(c,text='Exit').pack()
b.mainloop()
