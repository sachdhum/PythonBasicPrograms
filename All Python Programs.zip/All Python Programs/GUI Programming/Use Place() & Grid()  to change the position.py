from tkinter import *
a=Tk()
a.title("Python")
l=Label(text='First Name :',fg='red',bg='yellow').grid(row=0,column=0)
l=Label(text='Last Name :',fg='red',bg='yellow').grid(row=1,column=0,sticky='e')
a.geometry("500x500+200+200")
a.mainloop()
