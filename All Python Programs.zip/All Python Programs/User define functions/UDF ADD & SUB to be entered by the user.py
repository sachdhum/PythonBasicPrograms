def addition():
    n1=int(input("Enter any number: "))
    n2=int(input("Enter any number: "))
    n3=n1+n2
    print("The addition of these 2 numbers is: ",n3)

def subtraction():
    n1=int(input("Enter any number: "))
    n2=int(input("Enter any number: "))
    n3=n1-n2
    print("The subtraction of these 2 numbers is: ",n3)
