def name():
    n=input("Enter the name")
    print("My name is: ",n)
    name()
