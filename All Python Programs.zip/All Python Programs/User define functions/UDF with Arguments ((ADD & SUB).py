def addition(n1,n2):
    n3=n1+n2
    print(n1,"+",n2,"=",n3)

def subtraction(n1,n2):
    n3=n1-n2
    print(n1,"-",n2,"=",n3)
