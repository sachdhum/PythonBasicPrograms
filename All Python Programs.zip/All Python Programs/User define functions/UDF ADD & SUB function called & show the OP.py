Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: G:/All Python Programs/UDF ADD & SUB to be entered by the user.py ==
>>> addition()
Enter any number: 2
Enter any number: 4
The addition of these 2 numbers is:  6
>>> subtraction()
Enter any number: 4
Enter any number: 2
The subtraction of these 2 numbers is:  2
>>> 