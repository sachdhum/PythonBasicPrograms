name=input("Enter the name\t")
age=int(input("Enter the age\t"))
print("The name of the person is:",name,"& the age of the person is:",age)
input("Press enter to quit")
