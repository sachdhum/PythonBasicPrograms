from tkinter import *
a=Tk()
a.title("EA-Sports")
Button(text='Enter').pack()
a.mainloop()
