from tkinter import *
a=Tk()
def hello():
    l=Lable(text='Congrats! you have clicked on enter button').pack()
a.title("EA-Sports")
Button(text='Enter',command=hello,font=10).pack()
a.mainloop()
