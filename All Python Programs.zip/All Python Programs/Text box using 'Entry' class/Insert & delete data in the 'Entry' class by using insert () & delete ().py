from tkinter import *
a=Tk()
Label(text="First Name").grid(row=0)
Label(text="Last Name").grid(row=1)
e1=Entry(a)
e1.grid(row=0,column=1)
v="Sachin"
e1.insert(0,v)       
e1.delete(0,END)
e2=Entry(a)
e2.grid(row=1,column=1)
e2.insert(0,"Dhumale")
a.mainloop()

