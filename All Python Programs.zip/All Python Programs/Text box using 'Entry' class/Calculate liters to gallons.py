from tkinter import *
def mcal():
    var2=var1.get()
    var3=var2/3.785
    e2.insert(0,var3)
a=Tk()
var1=IntVar()
n='arial',10,'bold'
Label(text='Liters',padx=25,font=(n)).grid(row=0)
e1=Entry(a,width=25,textvariable=var1)
e1.grid(row=0,column=1)
Label(text='Gallons',padx=25,font=(n)).grid(row=1)
e2=Entry(a,width=25)
e2.grid(row=1,column=1)
Button(text='calculate',command=mcal,font=(n)).grid(row=2,column=1)
a.mainloop()

    

