from tkinter import *
a=Tk()
Label(text="First Name").grid(row=0)
Label(text="Last Name").grid(row=1)
e1=Entry(a)
e1.grid(row=0,column=1)
e2=Entry(a)
e2.grid(row=1,column=1)
a.mainloop()

