num1=int(input("Enter any number: "))
num2=int(input("Enter any number: "))
num3=int(input("Enter any number: "))
if(num1>num2)&(num1>num3):
    print(num1,"is the largest number among 3 numbers")
elif(num2>num3)&(num2>num1):
    print(num2,"is the largest number among 3 numbers")
else:
    print(num3,"is the largest number among 3 numbers")

input("press enter to quit")
