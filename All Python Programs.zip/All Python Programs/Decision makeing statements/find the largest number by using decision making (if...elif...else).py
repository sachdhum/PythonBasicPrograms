Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=10
>>> b=20
>>> c=30
>>> if(a==14):
	print(a)
elif(b==26):
	print(b)
else:
	print(c)

	
30
>>> if(a==14):
	print(a)
elif(b==20):
	print(b)
else:
	print(c)

	
20
>>> if(a==10):
	print(a)
elif(b==26):
	print(b)
else:
	print(c)

	
10
>>> 