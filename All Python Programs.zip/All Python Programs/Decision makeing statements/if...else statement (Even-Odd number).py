number=int(input("Enter any digit number\t"))
if(number%2==0):
    print(number,"The entered number is even number")
else:
    print(number,"The entered number is odd number")
    
input("press enter to quit")   
