c=input("Enter any alphabet\t")
if((c=='a')|(c=='e')|(c=='i')|(c=='o')|(c=='u')):
    print("The alphabet is Vowel",c)
else:
    print("The alphabet is Consonant",c)
    
input("Press enter to quit")
