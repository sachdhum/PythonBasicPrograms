Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> list=['Sachin','Dhumale',88,89,98]
>>> list
['Sachin', 'Dhumale', 88, 89, 98]
>>> list[0]
'Sachin'
>>> len(list)
5
>>> 
>>> list[1]
'Dhumale'
>>> list[:3]
['Sachin', 'Dhumale', 88]
>>> list[1:3]
['Dhumale', 88]
>>> list[-1]
98
>>> 