Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>>                         # DICTIONARIES
                        
>>> dict={'Sachin':29,'Gangadhar':30,'Anil':'Married',"Yogesh":25}
>>> dict
{'Sachin': 29, 'Gangadhar': 30, 'Anil': 'Married', 'Yogesh': 25}
>>> print(dict)
{'Sachin': 29, 'Gangadhar': 30, 'Anil': 'Married', 'Yogesh': 25}
>>> dict['sachin']
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    dict['sachin']
KeyError: 'sachin'
>>> dict['Sachin']
29
>>> dict['Radheshyam']=70
>>> dict
{'Sachin': 29, 'Gangadhar': 30, 'Anil': 'Married', 'Yogesh': 25, 'Radheshyam': 70}
>>>                   # We can add lists into the dictionaries
                  
>>> a=[1,2,3]
>>> b=[4,5,6]
>>> a
[1, 2, 3]
>>> b
[4, 5, 6]
>>> dict1{'a':[1,2,3],'b':[4,5,6]}
SyntaxError: invalid syntax
>>> dict1{'a':[1,2,3],'b':[4,5,6]}
SyntaxError: invalid syntax
>>> dict1{'a':[1,2,3],'b':[4,5,6]}
SyntaxError: invalid syntax
>>> print (dict['Radheshyam'])
70
>>> del dict['Yogesh']
>>> 
>>> dict
{'Sachin': 29, 'Gangadhar': 30, 'Anil': 'Married', 'Radheshyam': 70}
>>> 