Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> l=['ABC','PQR','XYZ',897,1098,1987,2020,2034]
>>> l
['ABC', 'PQR', 'XYZ', 897, 1098, 1987, 2020, 2034]
>>> for i in l:
	print (i)

	
ABC
PQR
XYZ
897
1098
1987
2020
2034
>>> #We will use some methods which are avilable in the lists
>>> l.append(198)
>>> l
['ABC', 'PQR', 'XYZ', 897, 1098, 1987, 2020, 2034, 198]
>>> l.count(2020)
1
>>> l.index(1987)
5
>>> l.remove(198)
>>> l
['ABC', 'PQR', 'XYZ', 897, 1098, 1987, 2020, 2034]
>>> l.reverse()
>>> l
[2034, 2020, 1987, 1098, 897, 'XYZ', 'PQR', 'ABC']
>>> l.pop()
'ABC'
>>> l
[2034, 2020, 1987, 1098, 897, 'XYZ', 'PQR']
>>> l.clear()
>>> l
[]
>>> 