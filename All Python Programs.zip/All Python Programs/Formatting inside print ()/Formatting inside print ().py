Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> name='sachin'
>>> age=29
>>> per=78.98
>>> print("The name is %s , the age is %d , & the percentage is %f"%(name,age,per))
The name is sachin , the age is 29 , & the percentage is 78.980000
>>> 