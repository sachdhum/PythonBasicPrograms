Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: G:/All Python Programs/Oop's Concept/More Functions using class &  object.py
>>> s=student("Sachin Dhumale")
Welcome Sachin Dhumale to the school
>>> s.attend
0
>>> s.attenddays()
>>> s.attend
1
>>> s.marks
[]
>>> s.addmarks(87)
>>> s.addmarks(90)
>>> s.addmarks(67)
>>> s.addmarks(98)
>>> s.addmarks(79)
>>> s.addmarks(86)
>>> s.marks
[87, 90, 67, 98, 79, 86]
>>> s.getavg()
84.5
>>> 