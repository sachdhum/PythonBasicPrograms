                         #Inheritance
class person:
    def __init__(self,n,a):
        self.n=n
        self.a=a
        print("The name of the person is {} & the age of the  person is {}".format(n,a))
class teacher(person):
    def print(self,n,a):
        person.__init__(self,n,a)
class student(person):
    def print(self,n,a):
        person.__init__(self,n,a)
