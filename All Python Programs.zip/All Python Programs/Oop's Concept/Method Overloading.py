                                                            # Method Overloading
class student:
    def __init__(self,n,a):
        self.n=n
        self.a=a
    def __str__(self):
            return("The name of the student is {}\n the age of the student is {}".format(self.n,self.a))
class teacher(student):
    def __init__(self,n,a,s):                                  
        student.__init__(self,n,a)
        self.s=s
    def __str__(self):
            return(student.__str__(self)+"\nThe subject of student is {}".format(self.s))
class staff(student):
    def __init__(self,n,a,s,l):
        student.__init__(self,n,a)
        self.l=l
    def __str__(self):
            return(student.__str__(self)+"\n The loan has been approved rs {}".format(self.l))

        

          
                   
        


   
    
