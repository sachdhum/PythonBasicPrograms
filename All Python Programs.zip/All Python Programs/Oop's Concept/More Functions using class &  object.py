class student:
    def __init__(self,n):
        self.n=n
        self.attend=0
        self.marks=[]
        print("Welcome {} to the school".format(n))
    def addmarks(self,ma):
        self.marks.append(ma)
    def attenddays(self):
        self.attend +=1
    def getavg(self):
        return sum(self.marks)/len(self.marks)
    
    
    
