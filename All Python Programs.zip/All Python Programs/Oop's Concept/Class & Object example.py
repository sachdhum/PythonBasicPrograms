class student:
    def details(self,name,age):
        self.name=name
        self.age=age
        print("The name of th student is {} & the age of the studnet is {}".format(name,age))
