                       # Constructor

class student:
    def __init__(self,n,a):
        self.n=n
        self.a=a
        self.bal=0
        self.credit=100
        print("The name of the student {} \n the age of the student {}".format(n,a))
