Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
========= RESTART: G:/All Python Programs/Oop's Concept/Inheritance.py =========
>>> s=student("Vishwa",70)
The name of the person is Vishwa & the age of the  person is 70
>>> t=teacher("Sachin Dhumale",30)
The name of the person is Sachin Dhumale & the age of the  person is 30
>>> p=person("Abdul",90)
The name of the person is Abdul & the age of the  person is 90
>>> 