                        # Constructor Functions / Methods

class person:
    def __init__(self,n,a):
        self.n=n
        self.a=a
        print("Welcome {}".format(n))
    def __str__(self):
       return("The name of the person is = {} & the age of the person is = {}".format(self.n,self.a))
    def __del__(self):
        print("{} is no more\nThe memory is free now".format(self.n))

p=person("Sachin Dhumale",30)
input()

print(p)
input()
del(p)
        
        
         
         
    
         

        

        
    

  
