Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
===== RESTART: G:/All Python Programs/Oop's Concept/Constructor Program.py =====
>>> s=student("Sachin",29)
The name of the student Sachin 
 the age of the student 29
>>> s.bal
0
>>> s.credit
100
>>> 