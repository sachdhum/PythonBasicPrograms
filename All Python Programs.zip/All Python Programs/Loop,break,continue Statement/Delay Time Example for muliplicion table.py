                       # Delay Time Example

import time
for a in range(1,5):
    print('\n')
    time.sleep(2)
    for b in range(1,5):
         print(a,"X",b,"=",a*b)
        
    
    


   

