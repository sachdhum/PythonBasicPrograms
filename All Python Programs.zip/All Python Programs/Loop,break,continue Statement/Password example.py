password="sachin@1991"
for i in range (3):
    pwd=input("Enter the password: ")
    j=2
    if(pwd==password):
        print("Wel-come")
        break
    else:
        print("Wrong Password,chances left",j-i)
        continue

input("Press enter to quit")
        
