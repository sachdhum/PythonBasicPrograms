                       # When User hits mannualy enter button on keyboard& then multiplictaion able shoul display

import time
for a in range(1,5):
    print('\n')
    input()
    for b in range(1,5):
         print(a,"X",b,"=",a*b)
        
    
    


   

