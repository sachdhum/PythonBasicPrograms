fact=1
num=int(input("Enter the number: "))
for i in range (1,(num+1)):
    fact=fact*i
    print("The factorial of",num,"is",fact)

input("Press enter to quit")
