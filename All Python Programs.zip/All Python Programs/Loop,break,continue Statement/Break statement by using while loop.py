i=1
while(i<10):
    print(i)
    if(i==8):
        break
    i=i+1
    
