num=int(input("Enter the number: "))
for i in range(1,11):
    print(num,"X",i,"=",num*i)

input("Press enter to quit")
