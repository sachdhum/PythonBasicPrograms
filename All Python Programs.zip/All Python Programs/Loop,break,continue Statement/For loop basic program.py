Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> for i in range(6)
SyntaxError: invalid syntax
>>> for i in range(6):
	print(i)

	
0
1
2
3
4
5
>>> for i in range(1,8):
	print(i)

	
1
2
3
4
5
6
7
>>> for i in range(1,9,2):
	print(i)

	
1
3
5
7
>>> 