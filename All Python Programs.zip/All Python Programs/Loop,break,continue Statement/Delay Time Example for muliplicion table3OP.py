Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: G:/All Python Programs/Delay Time Example for muliplicion table3.py =



1 X 1 = 1
1 X 2 = 2
1 X 3 = 3
1 X 4 = 4



2 X 1 = 2
2 X 2 = 4
2 X 3 = 6
2 X 4 = 8



3 X 1 = 3
3 X 2 = 6
3 X 3 = 9
3 X 4 = 12



4 X 1 = 4
4 X 2 = 8
4 X 3 = 12
4 X 4 = 16
>>> 