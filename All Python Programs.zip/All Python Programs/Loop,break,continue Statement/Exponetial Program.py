num=int(input("Enter the number: "))
exp=int(input("Enter the number: "))
res=1
for i in range(1,(exp+1)):
    res=res*num
print("The result is: ",res)

input("Plz press enter to quit")
    
