Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> n='Sachin'
>>> a=29
>>> print("The name of the student is {} & the age is {}".format(n,a))
The name of the student is Sachin & the age is 29
>>> #To print age first & later name second, we do following
>>> print("The name of the student is {} & the age of the student {}".format(a,n))
The name of the student is 29 & the age of the student Sachin
>>>  # TO give space between age & the literal value which will pass in the double quotation
 
>>> print("The age of the student is {:4} & the name of the student is {}".format(a,n))
The age of the student is   29 & the name of the student is Sachin
>>> print("The age of the student is {} & the name of the student {}".format(a,n))
The age of the student is 29 & the name of the student Sachin
>>> 