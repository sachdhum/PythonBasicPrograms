                       # Delay Time Example

import time
print("img1")
time.sleep(3)
print("img2")
time.sleep(3)
print("img3")
