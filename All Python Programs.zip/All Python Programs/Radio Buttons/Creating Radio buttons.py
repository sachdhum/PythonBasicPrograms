from tkinter import *
a2=Tk()
a2.title("Radio Buttons")
Radiobutton(text='Male',padx=40).pack()
Radiobutton(text='Female',padx=40).pack()
Radiobutton(text='Transgender',padx=40).pack()

a2.mainloop()
