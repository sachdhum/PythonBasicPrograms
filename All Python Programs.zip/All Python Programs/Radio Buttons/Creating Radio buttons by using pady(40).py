from tkinter import *
a2=Tk()
a2.title("Radio Buttons")
v=IntVar()
v.set(3)
Label(text='Choose a programming \nlanguage',padx=25,justify=LEFT).pack(anchor=W)
Radiobutton(text='Python',padx=25,variable=v,value=1).pack(anchor=W)
Radiobutton(text='C',padx=25,variable=v,value=2).pack(anchor=W)
Radiobutton(text='C++',padx=25,variable=v,value=3).pack(anchor=W)
Radiobutton(text='R',padx=25,variable=v,value=4).pack(anchor=W)
Radiobutton(text='Ruby',padx=25,variable=v,value=5).pack(anchor=W)

a2.mainloop()
