from tkinter import *
a2=Tk()
def mmm():
    a=v.get()
    if(a==1):
         a=Tk()
         a.title('Python')
         l1=Label(a,text='Welcome to python',font=('arial',30,'bold'))
         l1.pack()      
    elif (a==2):
        a=Tk()
        a.title('C')
        l1=Label(a,text='Welcome to C',font=('times',30,'bold'))
        l1.pack()
    elif (a==3):
        a=Tk()
        a.title('C++')
        l1=Label(a,text='Welcome to C++',font=('arial',30,'italic'))
        l1.pack()
    elif (a==4):
        a=Tk()
        a.title('R')
        l1=Label(a,text='Welcome to R',font=('times',30,'bold'))
        l1.pack()
    else:
        a=Tk()
        a.title('Ruby')
        l1=Label(a,text='Welcome to ruby',font=('times',30,'italic'))
        l1.pack()
         
            
a2.title("Radio Buttons")
v=IntVar()
v.set(3)
languages=[("Python",1),("C",2),("C++",3),("R",4),("Ruby",5)] 
Label(text='Choose a programming \nlanguage',padx=25,justify=LEFT).pack(anchor=W)
for txt, val in languages:
    Radiobutton(text=txt,padx=25,variable=v,value=val,command=mmm).pack(anchor=W)

    


a2.mainloop()
