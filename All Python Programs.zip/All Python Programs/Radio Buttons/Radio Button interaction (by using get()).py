from tkinter import *
a2=Tk()
def mmm():
    a=v.get()
    if(a==1):
         a=Tk()
         a.title('Python')
         l1=Label(a,text='Welcome to python',font=('arial',30,'bold'))
         l1.pack()      
    elif (a==2):
        a=Tk()
        a.title('C')
        l1=Label(a,text='Welcome to C',font=('times',30,'bold'))
        l1.pack()
    elif (a==3):
        a=Tk()
        a.title('C++')
        l1=Label(a,text='Welcome to C++',font=('arial',30,'italic'))
        l1.pack()
    elif (a==4):
        a=Tk()
        a.title('R')
        l1=Label(a,text='Welcome to R',font=('times',30,'bold'))
        l1.pack()
    else:
        a=Tk()
        a.title('Ruby')
        l1=Label(a,text='Welcome to ruby',font=('times',30,'italic'))
        l1.pack()
         
            
a2.title("Radio Buttons")
v=IntVar()
v.set(3)            # to set default value when program is excuted.
Label(text='Choose a programming \nlanguage',padx=25,justify=LEFT).pack(anchor=W)
Radiobutton(text='Python',padx=25,variable=v,value=1,command=mmm).pack(anchor=W)
Radiobutton(text='C',padx=25,variable=v,value=2,command=mmm).pack(anchor=W)
Radiobutton(text='C++',padx=25,variable=v,value=3,command=mmm).pack(anchor=W)
Radiobutton(text='R',padx=25,variable=v,value=4,command=mmm).pack(anchor=W)
Radiobutton(text='Ruby',padx=25,variable=v,value=5,command=mmm).pack(anchor=W)

a2.mainloop()
