Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:37:02) [MSC v.1924 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a="Sachin"
>>> b="Dhumale"
>>> print(a)
Sachin
>>> print(b)
Dhumale
>>> print(a+,": ",b)
SyntaxError: invalid syntax
>>> print(a+b)
SachinDhumale
>>> a.upper()
'SACHIN'
>>> a.lower()
'sachin'
>>> len(a)
6
>>> len(b)
7
>>> 