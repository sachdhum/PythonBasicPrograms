from tkinter import *
a2=Tk()
v=IntVar()
Checkbutton(text='Python',variable=v).pack(anchor=W)
v1=IntVar()
Checkbutton(text='Java',variable=v1).pack(anchor=W)
v2=IntVar()
Checkbutton(text='Selenium',variable=v2).pack(anchor=W)
v3=IntVar()
Checkbutton(text='DBMS',variable=v3).pack(anchor=W)
a2.mainloop()
 
