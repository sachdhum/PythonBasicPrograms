from tkinter import *
def mget():
    print(v.get(),v1.get(),v2.get(),v3.get())
a2=Tk()
v=IntVar()
Checkbutton(text='Python',variable=v).pack(anchor=W)
v1=IntVar()
Checkbutton(text='Java',variable=v1).pack(anchor=W)
v2=IntVar()
Checkbutton(text='Selenium',variable=v2).pack(anchor=W)
v3=IntVar()
Checkbutton(text='DBMS',variable=v3).pack(anchor=W)
Button(text='Get Values',command=mget).pack()
Button(text='Quit',command=a2.destroy).pack()
a2.mainloop()
 
