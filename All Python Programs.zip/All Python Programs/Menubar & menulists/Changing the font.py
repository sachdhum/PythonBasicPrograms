                        # changing the font

from tkinter import *
b=Tk()
b.title("Cricbuzz")
def new():
    lbl=Label(text='clicked on new file',font=('times',24,'bold')).pack()
    
m=Menu()
l=Menu()
l.add_command(label='new file',command=new)
m.add_cascade(label='File',menu=l)
b.config(menu=m)
b.mainloop()
