                        # Adding functionality to the menu list

from tkinter import *
b=Tk()
b.title("Cricbuzz")
def new():
    lbl=Label(text='clicked on new file',font=5).pack()
    
m=Menu()
l=Menu()
l.add_command(label='new file',command=new)
m.add_cascade(label='File',menu=l)
b.config(menu=m)
b.mainloop()
