                        # Creating Menubar

from tkinter import *
b=Tk()
b.title("Cricbuzz")
m=Menu()
m.add_cascade(label='File')
b.config(menu=m)
b.mainloop()
