                        # Adding menu list

from tkinter import *
b=Tk()
b.title("Cricbuzz")
m=Menu()
l=Menu()
l.add_command(label='new file')
m.add_cascade(label='File',menu=l)
b.config(menu=m)
b.mainloop()
