num=int(input("Enter the first number: "))
num1=int(input("Enter the second number: "))
try:
    num2=num/num1
except:
    print("You can not devide  number by zero")
else:
    print("The answer of above number is: ",num2)
input("Press enter to quit")

    
